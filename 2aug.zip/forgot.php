<?php 
		ob_start();
		include("includes/headerLogin-2.php");
include("includes/dbConf.php");
		$db=new dbConf();
		if(isset($_POST['submit'])){
		$mail=$_POST['email'];
		
 $checker=isvalid($mail);	
 if($checker=="That E-mail address was not found. Please enter the email address used at  registration"){
	$msg="That E-mail address was not found. Please enter the email address used at  registration"; 
	 }
	 else{
 
		$msg=smtpmail($mail,$checker);
 }
		}
?>



<style>
.login{
margin:auto;
border:1.5px solid #999;	
padding:2%;
background:#DDD;
height: 13em;
width: 35em;
-moz-border-radius: 1em 4em 1em 4em;
border-radius: 1em 4em 1em 4em
	
}
.login input{
	width:75%;
	display:block;
	padding:2%;
	margin-bottom:1em;
	font-size:1.3em;
	outline:none;
	border:1.5px solid #999;
	
}
.login button{
	padding:1% 3% 1% 3%;
	width:40%;
	font-size:1.3em;
}

.login a{
	margin-top:2%;
display:block;	
}
.login text{
	text-align:left;
}
</style>



<section class="login">
<fieldset >
<legend>&nbsp;&nbsp;&nbsp;Password change &nbsp;&nbsp;&nbsp;</legend>

<?php 	if ($msg != "")
	{ 
	echo"<table   >
				  <tr>
					<td style=width:auto >
					<div class=error>
					 <strong>$msg</strong></div>
					</td>
				  </tr>
	  </table>";
	}?>
    </th>
  </tr>
</table>

<form action="forgot.php" method="post" name="frmLogin">
<div align="center"> 
<input type="text" placeholder="inf@poc.org" name="email"></div>
<button type="reset" name="Cancel">Reset</button>
<button type="submit" name="submit">Submit Email</button>
<a href="index.php">Proceed to main site</a>
</form>
</fieldset>
</section>
<div class="clearer">&nbsp;</div>
	<div id="site-title">
</div>

	<?php
		include("includes/footer.php");
		?>	