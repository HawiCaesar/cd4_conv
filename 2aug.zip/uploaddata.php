<?php
session_start(); 
include('includes/Admin.php');
	
require_once ('excelreader/Excel/reader.php');
//require_once('connection/config.php');
?>

<style type="text/css">
select {
width: 250;}
</style>	
<div  class="section">
		<div class="section-title">Upload Facility Mapping </div>
		<div class="xtop">
		

			<?php   
			
if(isset($_POST['submit']))
{    $file1  = $_FILES['filename']['name'];
	 if  ($file1 =="" )
	{
		$error='<center>'."Please Select a Results Excel".'</center>';
	
		?>
		<table   >
  <tr>
    <td style="width:auto" ><div class="error"><?php 
		
echo  '<strong>'.' <font color="#666600">'.$error.'</strong>'.' </font>';

?></div></th>
  </tr>
</table>
<?php 

      print "<form action='' method='post' enctype='multipart/form-data'>";

echo "<table border='0' class='data-table'>	

		
		<tr >
		<td colspan='1'>
		Locate Excel file name to import:		</td>
     		<td colspan='5'><input type=file name=filename></td>
		
		</tr>	
<tr >
		<td colspan='6'>
		<input type='submit' name='submit' value='submit' class='button'></td>
     		
		</tr>	
		</table>";

     

      print "</form>";

} 
	

		elseif ($file1 !="" ) //work sheet not null
		{
			 $work=$_POST['work'];
  			 $imagename = $_FILES['filename']['name'];
			  $source = $_FILES['filename']['tmp_name'];
              $target = "UploadedData/".$imagename;
              move_uploaded_file($source, $target);
			  $imagepath = $imagename;
				$file = "UploadedData/".$imagepath; //This is the original file 
				$data = new Spreadsheet_Excel_Reader();
				$data->setOutputEncoding('CP1251');
				$data->read($file);
$dateruncompleted = $data->sheets[0]["cells"][7][2];
$count=0;
for ($x = 236; $x <=258; $x++) 
		{
			//$zz=5;
			
			//for ($zz = 1; $zz <=8; $zz++) 
		//	{
			$columnno=$zz;
			//echo "COLUMN ".$leta.$columnno .'<BR/>' ;
			$consumption = $data->sheets[0]["cells"][$x][$zz];
			//$icod = $data->sheets[0]["cells"][$x][$zz+1];
			//ECHO  "COLUMN".$columnno.'dATA' .$hivod .  "<br/>";
			$districtname = mysql_real_escape_string($data->sheets[0]["cells"][$x][1]);
			if ($districtname !="")
			{ $districtID= GetDistrictIDfromName($districtname);}
			else {}		
			$centralsitename = mysql_real_escape_string($data->sheets[0]["cells"][$x][2]);
			$referalsitename = mysql_real_escape_string($data->sheets[0]["cells"][$x][3]);
			$mothersiteforreferallename = mysql_real_escape_string($data->sheets[0]["cells"][$x][4]);
			$sitecode = $data->sheets[0]["cells"][$x][5];
			$distance = $data->sheets[0]["cells"][$x][6];
			$ftype = $data->sheets[0]["cells"][$x][7];
			if ($ftype !="")
			{ $ftypeID= GetFacilityTypeID($ftype);			}
			else {}			
			
			$patontreatment = $data->sheets[0]["cells"][$x][8];
			$patoncare = $data->sheets[0]["cells"][$x][9];
			
			$cat1 = $data->sheets[0]["cells"][$x][11];
			$cat2 = $data->sheets[0]["cells"][$x][12];
			$cat3= $data->sheets[0]["cells"][$x][13];
			$cat4= $data->sheets[0]["cells"][$x][14];
			$cat5= $data->sheets[0]["cells"][$x][15];
			$cat6= $data->sheets[0]["cells"][$x][16];

			// echo  "Column No " . $columnno .  "<br/>";
			
			IF ($centralsitename =="") //referall
			{
			$level=1;
			$mothersitename=$mothersiteforreferallename ;
			$facilityname=$referalsitename;
			}
			ELSE  // central sites
			{
			$level=0;
			$mothersitename="" ;
			$facilityname=$centralsitename;
			}
			
			IF ($districtname =="") // blank column
			{
			
			}
			else
			{ 
			$updatesampleresults = mysql_query(" insert into facility(MFLCode,name,district,districtname,type,typename,centralsitename,level,distance) values ('$sitecode','$facilityname','$districtID','$districtname','$ftypeID','$ftype','$mothersitename','$level','$distance')");
			}

	IF ($updatesampleresults)
	{
		IF ($districtname =="") // blank column
			{
			
			}
			else
			{ 
		$fcode=GetFacilityAutoID($facilityname);
		$updatesampleresults = mysql_query("insert into facilitypatients(facility,fname,ontreatment,oncare) values ('$fcode','$facilityname','$patontreatment','$patoncare')");
				
				IF ($updatesampleresults) //INSERT EQUIPMENTS
				{
				if ($cat1 !="" && $cat1 !="-" )
				{ $cat1ID=GetEquipmentIDfromName($cat1,1);
				$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat1ID','$cat1')");}
				if ($cat2 !="" && $cat2 !="-")
				{	 $cat2ID=GetEquipmentIDfromName($cat2,2);
	$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat2ID','$cat2')");}
				if ($cat3 !="" && $cat3 !="-")
				{$cat3ID=GetEquipmentIDfromName($cat3,3);
				$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat3ID','$cat3')");}
				if ($cat4 !="" && $cat4 !="-")
				{$cat4ID=GetEquipmentIDfromName($cat4,4);
				$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat4ID','$cat4')");}
				if ($cat5 !="" && $cat5 !="-")
				{$cat5ID=GetEquipmentIDfromName($cat5,5);
				$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat5ID','$cat5')");}
				if ($cat6 !="" && $cat6 !="-")
				{ $cat6ID=GetEquipmentIDfromName($cat6,6);
				$updatesampleresults = mysql_query("insert into facilityequipments(facility,fname,equipment,equipmentname) values ('$fcode','$facilityname','$cat6ID','$cat6')");
				}
				
				}


			}//end while
	
	}
			
			 $count ++;
			
			// $zz=$zz+1;
			 $yy=$yy+1;
			
			//}//ennd inn for
			  $leta++;
		}//end for


 if  (  $updatesampleresults    )
	 {
	 echo "Success";
	 }
						
	
unlink($file);		

							


} // end if filename not null
 
 }// end if submitted
   else //not submiited
   {





      print "<form action='' method='post' enctype='multipart/form-data'>";

echo "<table border='0' class='data-table'>	
		<tr >
		<td colspan='1'>
		Locate Excel file name to import:		</td>
     		<td colspan='5'><input type=file name=filename></td>
		
		</tr>	
<tr>
		<td colspan='6'>
		<input type='submit' name='submit' value='submit' class='button'></td>
     		
		</tr>	
		</table>";

     

      print "</form>";

   }
 
   ?>	
       
	
	
		</div>
		</div>
		
 <?php include('includes/footer.php');?>