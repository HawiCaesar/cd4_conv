<?php
include 'includes/dbConf.php';
$db=new dbConf();

function checkifrowexists($mfl,$drug){
	$sql="SELECT count(commodityID) FROM commoditytemp where mflcode='$mfl' AND reagentID='$drug'";
	$q=mysql_query($sql) or die();
	$rs=mysql_fetch_row($q);
	return $rs[0];
}

if(isset($_POST['facility_code'])){
$facility_code=$_POST['facility_code'];
$drug_id=$_POST['drug_id'];
$beg_bal=$_POST['beginning_bal'];
$received_qty=$_POST['received_qty'];
$received_lot=$_POST['received_lot'];
$qty_used=$_POST['qty_used'];
$losses=$_POST['losses'];
$adjustmentplus=$_POST['adjustmentplus'];
$adjustmentminus=$_POST['adjustmentminus'];
$endbal=$_POST['endbal'];
$requested=$_POST['requested'];
$to=$_POST['to'];
$from=$_POST['from'];
$caliburtests=$_POST['caliburtests'];
$caliburs=$_POST['caliburs'];
$counttests=$_POST['counttests'];
$counts=$_POST['counts'];
$cyflowtests=$_POST['cyflowtests'];
$cyflows=$_POST['cyflows'];

//echo "This what you have post facility= $facility_code $to $from $caliburtests $caliburs $counttests $counts $cyflowtests $cyflows $drug_id $beg_bal $received_qty $received_lot $qty_used $losses $adjustmentplus $adjustmentminus $endbal $requested";
$count=checkifrowexists($facility_code,$drug_id);
if($count>0){
$sql="UPDATE  `commoditytemp` SET  `fromdate` =  '$from', `todate` =  '$to',`caliburtests`='$caliburtests',`caliburs`='$caliburs',`counttests`='$counttests', `counts`='$counts', `cyflowtests`='$cyflowtests',
`cyflows`='$cyflows', `beginningbal`='$beg_bal', `receivedqty`='$received_qty', `receivedlot`='$received_lot', `qtyused`='$qty_used', `losses`= '$losses', `adjustmentplus`='$adjustmentplus', `adjustmentminus`='$adjustmentminus', `endbal`='$endbal', `requested`='$requested'
  WHERE  `mflcode` =  '$facility_code' AND  `reagentID`='$drug_id'";
}
else if($count==0) {
$sql="INSERT INTO `commoditytemp` (`mflcode`, `fromdate`, `todate`, `caliburtests`, `caliburs`, `counttests`, `counts`, `cyflowtests`, `cyflows`, `beginningbal`,
 `receivedqty`, `receivedlot`, `qtyused`, `losses`, `adjustmentplus`, `adjustmentminus`, `endbal`, `requested`, `reagentID`)
  VALUES ('$facility_code', '$from', '$to', '$caliburtests', '$caliburs', '$counttests', '$counts', '$cyflowtests', '$cyflows', '$beg_bal', '$received_qty', '$received_lot', '$qty_used', '$losses', '$adjustmentplus', '$adjustmentminus', '$endbal', '$requested', '$drug_id');";
}
echo $sql;
$query=mysql_query($sql) or die(mysql_error());
}
?>