<?php
session_start();
include("includes/commodityheader.php");
include("includes/dbConf.php");
$db=new dbConf();
$mine=$_SESSION['userID'];
?>
    <div class="main" id="main-two-columns" valign="top" class="xtop">
       <div class="left" id="main-left">
          <div class="post">
			<div class="post-body">
                <div class="section-title"><center>UPLOAD OF FACS CALIBUR RESULTS WAS SUCCESSFUL!!!</center>