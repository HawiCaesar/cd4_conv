 <?php
require_once("includes/dbConf.php");
$db = new dbConf();
//$user=getUser();
 $sta=$_GET['status'];
 $userID=$_GET['id'];
 $feedback="changes have been made";
$status=changeStatus($userID, $sta);
	
?>

<?php require_once("includes/admin.php"); ?>
<script>
$().ready(function(){
	

	
	
});
</script>

		<div class="main" id="main-two-columns">

			<div class="left" id="main-left">

			  <div class="post">
			  	<div class="section-title"><center><b><strong>View User Details</strong></b></center></div>
                 <center>
                   <form action="User.php" method="post" name="frmUsers" >
                   <div id="message">
                   
                   
                     <table  class="data-table">
                        
                       	<tr class="even">
                        <td><strong> <center>#</center> </strong></td> 
                          <td><strong><center>Username</center></strong></td>                         
                           <td><strong><center>Partner</center></strong></td>
                           <td><strong><center>status</center></strong></td>
                          <td><strong><center>Last Login</center></strong></td>

                        </tr>
                        
                         <?php
						 $num=1;
							  //calls function with users
                                foreach(getUser() as $myArr => $value){
									
									$id=$value['userGroupID'];
									$pid=$value['partnerID'];
									if($id!=2){
							  ?>
 						 <tr>
                              <td> <center><?php echo $num;  $num+=1; ?></center></td>
  							  <td> <center><?php echo $value['userName'];  ?></center></td>
                              <td> <center> <?php $phone=getSpecificPartner($pid); 
							  				echo $phone[2];
							  ?>
                              	</center>			
                              </td>
                              
                              
                              <td> <center><?php 
							     if($value['status']==1){
								 ?>  <?php echo "Account Enabled"; ?> 
                                 <?php
									 }
								 else{
								  ?> 
                                     <?php echo "Account Disabled"; ?> 
                                  <?php } ?></center>
							   </td>
                               
                               
                              <td><center> <?php echo $value['lastLogin']; ?></center></td>
  						 </tr>
                         <?php
									}
								}
                         ?>
                              
					</table></div>
                    </form>
                </center>
                    
					<div class="clearer">&nbsp;</div>

      </div>

				<div class="content-separator"></div>
				
			</div>

			<?php  	
			
				include("includes/sideAdmin.php"); ?>

			<div class="clearer">&nbsp;</div>

		</div>

		<div id="dashboard">

			<div class="column left" id="column-1">
				
				<div class="column-content">
				
			

				</div>

			</div>

			<div class="column left" id="column-2">

				<div class="column-content">
				
					

					
				</div>

			</div>

			<div class="column left" id="column-3">

				<div class="column-content">
				
					
				
				</div>

			</div>

		

			<div class="clearer">&nbsp;</div>

		</div>

	<?php
	
		include("includes/footer.php");
  ob_end_flush();
		?>	

