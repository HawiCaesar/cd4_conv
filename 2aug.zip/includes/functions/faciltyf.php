<?php
//check for facility from ID
		function checkFacility($id){
			$sql="select facilityName FROM facilitys where facilityID='".$id."'";
			$querySql=mysql_query($sql);
			$result=mysql_fetch_array($querySql);
			$myFacArr=array();
			for($i=0;$result;$i++){
				
				$myFacArr[$i]=$result;
				}
			return $myFacArr;
			
			}	

//get facility name given mfl
		function checkFacilitymfl($mfl){
			$sql="select name FROM facility where MFLCode='".$mfl."'";
			$querySql=mysql_query($sql);
			$result=mysql_fetch_row($querySql);
			return $result[0];
			
			}	
		
		function checkFacilitypass($mfl){
			$sql="select password FROM facility where MFLCode='".$mfl."'";
			$querySql=mysql_query($sql);
			$result=mysql_fetch_row($querySql);
			return $result[0];
			
			}	

	  
//get number of facilities by partner
	  function totalFacilitys($patna){
	   $sequel="SELECT COUNT(facilityID) AS fac
              FROM  `facilitys` WHERE facilitys.partner='".$patna."' ";
      
	  $resultReport=mysql_query($sequel);
	  $myArr=array();
	  while($resultArr=mysql_fetch_array($resultReport)){
		  echo $myArr['1']=$resultArr['fac'];
		  }
	  }
	  
//facility details by certain partner
	function gettotalfac($patna){
		$sql="SELECT count(*) as fac FROM  `facilitys` WHERE  `partner` ='".$patna."' ";
		$query=mysql_query($sql);
		while($rs=mysql_fetch_array($query)){
			$total=$rs['fac'];
			}
		return $total;
		}	
	
	function reportFacility($patna,$num){
		$sql="SELECT * FROM  `facilitys` WHERE  `partner` ='".$patna."' LIMIT 0 ," .$num;
		$query=mysql_query($sql);
		return $query;
		
		}
	function getSpecFacility($num){
		$sql="SELECT * FROM  `facilitys` WHERE  `facilityID` ='".$num."' LIMIT 0 ,1" ;
		$query=mysql_query($sql);
		return $query;
		
		}
			  			
	
//get  all the facilities and their details	
		function getFacility(){
			$sql="select * from facilitycounty order by facility asc";
			$executeSql=mysql_query($sql);
			$res_array = array();
			for($count = 0; @$row = mysql_fetch_array($executeSql); $count++)  {   
            $res_array[$count] = $row;
        		}
			return $res_array;
			}
			
function getSpecDistrict($district){
		$sql="SELECT name as name FROM  `districts` WHERE  `ID` ='".$district."'";
		$query=mysql_query($sql);
		while($rs=mysql_fetch_array($query)){
			$name=$rs['name'];
			}
		echo $name;
		
		}
function patientspercentral($site,$level){
	if ($level==1){
	$sql="SELECT sum(`ontreatment` ) FROM `facilitywithpatients`WHERE (AutoID ='$site' OR centralsiteAutoID ='$site')";
	}
	else if ($level==2){
	$sql="SELECT sum(`oncare` ) FROM `facilitywithpatients`WHERE (AutoID ='$site' OR centralsiteAutoID ='$site')";
	}
	else {
	$sql="SELECT (sum(`ontreatment` )+sum(`oncare` )) FROM `facilitywithpatients`WHERE (AutoID ='$site' OR centralsiteAutoID ='$site')";
	}
    $query=mysql_query($sql) or die (mysql_error());
	$re=mysql_fetch_row($query);
	return $re[0];
}

//facility name
function GetFacilityName1($fid)
{
			$cquery=mysql_query("SELECT name as fname FROM facility  WHERE  AutoID='$fid'") or die(mysql_error()); 
			$noticia = mysql_fetch_row($cquery);  
			$fid=$noticia[0];
			return $fid;
}
	
//facility service used
function facilityservices($facility){
	$sql="SELECT ANC,PMTCT FROM facilitys where facilitycode='$facility'";
	$query=mysql_query($sql) or die(mysql_error());
	$rs=mysql_fetch_row($query);
	echo '<td><div align="center">'.$rs[0].' </div></td> <td><div align="center">'.$rs[1].'</div></td> ';
}			
?>