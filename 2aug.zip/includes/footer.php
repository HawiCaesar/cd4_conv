<div id="footer">

			<div class="left">&nbsp;</div>
			<div class="right"> &copy; <?php echo date('Y');?> NASCOP </div>

			<div class="clearer">&nbsp;</div>

		</div>

	</div>
</div>

</body>
</html>