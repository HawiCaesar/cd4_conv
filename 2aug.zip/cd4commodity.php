<?php
@session_start();
if(!isset($_SESSION['username'])){
	echo "<script>";
		echo "window.location.href='facilitylogin.php'";
	echo "</script>";
}
include ("includes/commodityheader.php");
require_once ("includes/dbConf.php");
$db = new dbConf();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$from = date('Y-m-d', strtotime($_POST['from']));
	$to = date('Y-m-d', strtotime($_POST['to']));
	submitcommodity($_POST['mfl'], $from, $to, $_POST['caliburtests'], $_POST['caliburs'], $_POST['counttests'], $_POST['counts'], $_POST['cyflowtests'], $_POST['cyflows'], $_POST['beginningbal'], $_POST['receivedqty'], $_POST['receivedlot'], $_POST['qtyused'], $_POST['losses'], $_POST['adjustmentplus'], $_POST['adjustmentminus'], $_POST['endbal'], $_POST['requested'], $_POST['namer']);
}

$arr=loadcommoditypage($_SESSION['facility']);
?>
<script type="text/javascript">
	$(document).ready(function() {
		<?php if(sizeof($arr)<0){
			?>
			
		
		$("#from").val("<?php echo $arr[0]['fromdate']; ?>");
		$("#to").val("<?php echo $arr[0]['todate']; ?>");
		$("#caliburs").val("<?php echo $arr[0]['caliburs']; ?>");
		$("#counts").val("<?php echo $arr[0]['counts']; ?>");
		$("#cyflows").val("<?php echo $arr[0]['cyflows']; ?>");
		$("#caliburtests").val("<?php echo $arr[0]['caliburtests']; ?>");
		$("#counttests").val("<?php echo $arr[0]['counttests']; ?>");
		$("#cyflowtests").val("<?php echo $arr[0]['cyflowtests']; ?>");
		//$("input[name='beginningbal[1]']").val();
		
		<?php 
		}
		
		  foreach($arr as $ar){
		 ?>
		  var row_id=<?php echo $ar['reagentID']; ?>;
		  
		  $("input[name='beginningbal["+row_id+"]']").val("<?php echo $ar['beginningbal'];?>");
		  $("input[name='receivedqty["+row_id+"]']").val("<?php echo $ar['receivedqty'];?>");
		  $("input[name='receivedlot["+row_id+"]']").val("<?php echo $ar['receivedlot'];?>");
		  $("input[name='qtyused["+row_id+"]']").val("<?php echo $ar['qtyused'];?>");
		  $("input[name='losses["+row_id+"]']").val("<?php echo $ar['losses'];?>");
		  $("input[name='adjustmentplus["+row_id+"]']").val("<?php echo $ar['adjustmentplus'];?>");
		  $("input[name='adjustmentminus["+row_id+"]']").val("<?php echo $ar['adjustmentminus'];?>");
		  $("input[name='endbal["+row_id+"]']").val("<?php echo $ar['endbal'];?>");
		  $("input[name='requested["+row_id+"]']").val("<?php echo $ar['requested'];?>");
		 <?php 	
		  }
		 ?>
		
		
		
		//bind event
		$(".text").live("click keyup", function (event){
			 var row_id=$(this).attr("test");
			 
			 var items="facility_code="+$('input[name=mfl]').val()
			 +"&to="+$("#to").val()
			 +"&from="+$("#from").val()
			 +"&caliburs="+$("#caliburs").val()
			 +"&caliburtests="+$("#caliburtests").val()
			 +"&counts="+$("#counts").val()
			 +"&counttests="+$("#counttests").val()
			 +"&cyflows="+$("#cyflows").val()
			 +"&cyflowtests="+$("#cyflowtests").val()
			 +"&drug_id="+$(document.getElementsByName("namer["+row_id+"]")).val()
			  +"&beginning_bal="+$(document.getElementsByName("beginningbal["+row_id+"]")).val()
			  +"&received_qty="+$(document.getElementsByName("receivedqty["+row_id+"]")).val()
			  +"&received_lot="+$(document.getElementsByName("receivedlot["+row_id+"]")).val()
			  +"&qty_used="+$(document.getElementsByName("qtyused["+row_id+"]")).val()
			  +"&losses="+$(document.getElementsByName("losses["+row_id+"]")).val()
			  +"&adjustmentplus="+$(document.getElementsByName("adjustmentplus["+row_id+"]")).val()
			  +"&adjustmentminus="+$(document.getElementsByName("adjustmentminus["+row_id+"]")).val()
			  +"&endbal="+$(document.getElementsByName("endbal["+row_id+"]")).val()
			  +"&requested="+$(document.getElementsByName("requested["+row_id+"]")).val();
			 
			 var url_ ='<?php echo "http://".$_SERVER['SERVER_NAME']."/cd4/test_ajax_post.php"; ?>';
			 
			$.ajax({
				type:"POST",
				data:items,
				url:url_,
				beforeSend: function(){
					
				},
				success: function(msg){
					console.log(msg);
				}
			});
		});
		
		$("#to").datepicker({
			yearRange : "-120:+0",
			maxDate : "0D",
			dateFormat : $.datepicker.ATOM,
			changeMonth : true,
			changeYear : true
		});
		$("#from").datepicker({
			yearRange : "-120:+0",
			maxDate : "0D",
			dateFormat : $.datepicker.ATOM,
			changeMonth : true,
			changeYear : true
		});
		
		$("#facilities").change(function() {
			// alert($(this).val());
			var code = $("#facilities").val();

			var code_array = code.split("|");
			$('input:[name=mfl]').val(code_array[1]);
			$('input:[name=district]').val(code_array[3]);
			$('input:[name=county]').val(code_array[4]);

			switch (code_array[2]) {
				case 'MoH':
					$('#MoH').attr('checked', 'checked');
					break;
				case 'LA':
					$('#LA').attr('checked', 'checked');
					break;
				case 'FBO':
					$('#FBO').attr('checked', 'checked');
					break;
				case 'NGO':
					$('#NGO').attr('checked', 'checked');
					break;
				case 'Private':
					$('#private').attr('checked', 'checked');
					break;
				default:
					$('#others').attr('checked', 'checked');
					break;
			}
		});

		$('#caliburtests').keyup(function() {
			var code = $("#caliburtests").val();
			$('#1').val(code / 50);
			$('#3').val(code / 2000);
			$('#6').val(code / 500);

		});
		$('#caliburs').keyup(function() {
			var code= $("#caliburs").val();
			//var code1 = ($("#to").val() - $("#from").val());
			$("#to").datepicker({
				dateFormat : 'mm/dd/yy'
			});
			
			
		
		//var month=$("#to").val();
		var month2 = $("#from").val();
		var date = $('#to').datepicker('getDate');
		var today = $('#from').datepicker('getDate');
		var diff = Math.floor(((date - today) / (1000 * 60 * 60 * 24)/28));
		$('#2').val(diff*code);
		$('#4').val(diff*code/3);
		$('#5').val(diff*code/3);
		$('#8').val(diff*code);
		$('#9').val(diff*code);
});


		$('#counttests').keyup(function() {
			var code = $("#counttests").val();
			$('#21').val(code / 50);
			$('#23').val(code / 500);
			$('#26').val((code / 100)/5);

		});
		
		$('#counts').keyup(function() {
			var code= $("#counts").val();
			//var code1 = ($("#to").val() - $("#from").val());
			$("#to").datepicker({
				dateFormat : 'mm/dd/yy'
			});
			
			
		
		//var month=$("#to").val();
		var month2 = $("#from").val();
		var date = $('#to').datepicker('getDate');
		var today = $('#from').datepicker('getDate');
		var diff = Math.floor(((date - today) / (1000 * 60 * 60 * 24)/28));
		$('#22').val(diff*code);
		$('#24').val(diff*code/3);
		$('#25').val(diff*code/3);
});


		$('#cyflowtests').keyup(function() {
			var code = $("#cyflowtests").val();
			var code2 = $("#totalsites").val();
			$('#12').val((Math.ceil((code / 100)/code2))*code);
			$('#13').val(code2*6);
			//$('#26').val((code / 100)/5);

		});
		

		
	});

</script>

<?php
$mflcode=$_SESSION['facility'];
$sql="SELECT * FROM `equipmentdetails` WHERE MFLCode='$mflcode' GROUP BY MFLCode";
$q=mysql_query($sql) or die(mysql_error());
$rs=mysql_fetch_row($q);

?>
	<div class="main" id="main-two-columns">
       	<h2 style="text-align:center; font-size: 20px;">FACILITY CONSUMPTION DATA REPORT & REQUEST(F-CDRR) FOR ART LABORATORY MONITORING REAGENTS</h2>
<form method="post" action="cd4commodity.php">

<table class="data-table1">
		
	<tr>
    <td><b>Name of Facility:</b></td>
    <td colspan="3"><input name="fac" type="input" class="texts" disabled value="<?php echo $_SESSION['username'];?>" size="35"/></td>
    <td><b>Facility Code:</b></td>
    <td><input type="text" name="mfl"  class="texts"  value="<?php echo $_SESSION['facility'];?>" disable /></td>
    <td><b>District:</b></td>
    <td><input type="text" name="district"  class="texts" disable value="<?php echo $rs[14];?>" /></td>
    <td><b>Province/County:</b></td> 
    <td><input type="text" name="county" class="texts"  disable value="<?php echo  $rs[16];?>" /> </td>
    <td><b>Affiliation:</b></td> 
    <td><input type="text"  class="texts" name="affiliation" disable value="<?php echo  $rs[8];?>" /> </td>
  </tr>
  
  <tr>
    <td align="right" colspan="2"><b>REPORT FOR PERIOD:</b></td>
    <td colspan="2"><b>BEGINNING:</b></td>
    <td colspan="2"><input type="text" name="from" id="from" class="texts" placeholder="DD/MM/YYYY" required value=""  /></td>
    <td colspan="2"><b>ENDING:<b></td>
    <td colspan="2"><input type="text" name="to" id="to" class="texts" placeholder="DD/MM/YYYY"  required value="" /></td>
    <td colspan="2"></td>    
  </tr>
  <tr>
    <th colspan="2" align="left"><b>State the number of CD4 Tests conducted:-</b></th>
    <td colspan="3"><b> Calibur:</b><input placeholder="Pead Tests" name="caliburtests" id="caliburtests" class="texts" required value=""  size="6"/>&nbsp;&nbsp;<input placeholder="Adult Tests" name="caliburtest" id="caliburtest" required value=""  class="texts"  size="6"/>&nbsp;&nbsp;<input placeholder="Equip No." name="caliburs"  id="caliburs" class="texts" size="6" required value="" /></td>
    <td colspan="3"><b> Count:</b><input placeholder="Pead Tests" name="counttests" id="counttests"  class="texts" required value=""  size="6" />&nbsp;&nbsp;<input placeholder="Adult Tests" name="counttests" id="counttest"  required value=""  class="texts" size="6" />&nbsp;&nbsp;<input placeholder="Equip No." name="counts" id="counts" class="texts" size="6" required value="" /></td>
    <td colspan="4"><b>Cyflow Partec:</b> <input placeholder="Pead Tests" name="cyflowtests" id="cyflowtests" class="texts" size="6" required value=""  />&nbsp;&nbsp;<input placeholder="Adult Tests" name="cyflowtest" id="cyflowtest" class="texts" size="6" required value=""  />&nbsp;&nbsp;<input placeholder="Equip No." name="cyflows" id="cyflows" class="texts" size="6" required value="" /><input type="hidden" name="totalsites"  id="totalsites" value="1"/></td>    
  </tr>
  <tr>
    <td colspan="6"><b>TOTAL NUMBER OF CD4 TESTS DONE DURING THE MONTH(REPORTING PERIOD):</b></td>
    <td colspan="8">&nbsp;</td>
    
  </tr>


<tr>		 <td rowspan="2"><b>COMMODITY CODE</b></td>
			<td rowspan="2"><b>COMMODITY NAME</b></td>
            <td rowspan="2"><b>UNIT OF ISSUE</b></td>
            <td rowspan="2"><b>BEGINNING BALANCE</b></td>
            <td colspan="2"><b>QUANTITY RECEIVED FROM CENTRAL<br/> WAREHOUSE (e.g. KEMSA)</b></td>             
            <td rowspan="2"><b>QUANTITY USED</b></td>
            <td rowspan="2"><b>LOSSES/WASTAGE</b></td>
            <td colspan="2"><b>ADJUSTMENTS<br/><i>Indicate if (+) or (-)</i></b></td>
            <td rowspan="2"><b>ENDING BALANCE <br/>PYSICAL COUNT at end of the Month</b></td>
            <td rowspan="2"><b>QUANTITY REQUESTED</b></td>
            </tr>
            
            
            <tr>      
             <td>Quantity</td>
            <td>Lot No.</td>
            <td>Positive</td>
            <td>Negative</td>    
            </tr>
            
<?php
reagentCategory($_SESSION['facility']);
			?>
			<tr><td colspan="12"><textarea placeholder="FCDRR Comments" name="comments" cols="250"></textarea></td></tr>
<tr><td colspan="4"><input type="submit" name="submit" value="Submit Commodity Report" class="button" /></td>
	<td colspan="4"><input type="submit" name="savenleave" value="Save and Submit Later" class="button" /></td>
	<td colspan="4"><input type="submit" name="print" value="Print" class="button" /></td></tr>
</table>
</form>
<div class="clearer">&nbsp;</div>
 </div>
<?php
include 'includes/footer.php';
?>