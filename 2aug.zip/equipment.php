 <?php
 //echo  $_SERVER[PHP_SELF].$_SERVER['QUERY_STRING'];
require_once("includes/programheader.php");
require_once("includes/dbConf.php");
require_once("function.php");
require_once("includes/paginator.php");

if(isset($_GET['ipp'])){
	if($_GET['ipp']!='All'){
	$lim="LIMIT ".(($_GET['ipp']*$_GET['page'])-$_GET['ipp']).",".($_GET['ipp']);
	 }
	else {  $lim=""; }
}
else{$lim="LIMIT 0,20";}

if(isset($_GET['id']) && $_GET['id']!=0 ){
	$cat=$_GET['id'];	
}
else{$cat=1;}


$db = new dbConf();
if(isset($_POST['submitsearch'])){
	$placement=$_POST['sampleNo'];
$a="SELECT * FROM facilityequipments, equipments, equipmentcategories,facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID AND facilitycounty.AutoID=facilityequipments.facility AND facilityequipments.equipmentname='$placement' order by facilitycounty.county ".$lim ;
$k="SELECT facilityequipments.facility,facilityequipments.fname,facilityequipments.equipment,facilityequipments.equipmentname,
facilityequipments.status,equipments.description as description,equipments.category,equipmentcategories.description as cat,
facilitycounty.AutoID,facilitycounty.MFLCode,facilitycounty.facility,facilitycounty.countyID,facilitycounty.county FROM facilityequipments, equipments, equipmentcategories,
facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID AND facilitycounty.AutoID=facilityequipments.facility AND facilityequipments.equipmentname='$placement'";
$q=mysql_query($a) or die(mysql_error());	
}
else{
if($_GET['id']=='1a' || $_GET['id']=='2a' || $_GET['id']=='3a'){
$cat=substr($_GET['id'],0,-1);
$k="SELECT facilityequipments.facility,facilityequipments.fname,facilityequipments.equipment,facilityequipments.equipmentname,
facilityequipments.status,equipments.description as description,equipments.category,equipmentcategories.description as cat,
facilitycounty.AutoID,facilitycounty.MFLCode,facilitycounty.facility,facilitycounty.countyID,facilitycounty.county  FROM facilityequipments,
 equipments, equipmentcategories,facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID 
  AND facilitycounty.AutoID=facilityequipments.facility AND equipments.category	='$cat'";
$q=mysql_query("SELECT facilityequipments.facility,facilityequipments.fname,facilityequipments.equipment,facilityequipments.equipmentname,
facilityequipments.status,equipments.description as description,equipments.category,equipmentcategories.description as cat,
facilitycounty.AutoID,facilitycounty.MFLCode,facilitycounty.facility,facilitycounty.countyID,facilitycounty.county  FROM facilityequipments,
 equipments, equipmentcategories,facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID 
  AND facilitycounty.AutoID=facilityequipments.facility AND equipments.category	='$cat'".$lim) or die(mysql_error());	
}
else{
$k="SELECT * FROM facilityequipments, equipments, equipmentcategories,facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID  AND facilitycounty.AutoID=facilityequipments.facility AND facilityequipments.equipment	='$cat' "	;
$q=mysql_query("SELECT facilityequipments.facility,facilityequipments.fname,facilityequipments.equipment,facilityequipments.equipmentname,
facilityequipments.status,equipments.description as description,equipments.category,equipmentcategories.description as cat,
facilitycounty.AutoID,facilitycounty.MFLCode,facilitycounty.facility,facilitycounty.countyID,facilitycounty.county  FROM facilityequipments, equipments, equipmentcategories,facilitycounty WHERE facilityequipments.equipment = equipments.ID  AND equipments.category = equipmentcategories.ID  AND facilitycounty.AutoID=facilityequipments.facility AND facilityequipments.equipment	='$cat'".$lim) or die(mysql_error());
  }
 }  
?>


 
<SCRIPT language=JavaScript>
function reload(form)
{
var val=form.account.options[form.account.options.selectedIndex].value;
self.location='equipment.php?account=' + val  ;
}
$().ready(function() {
	
	$("#sampleNo").autocomplete("getequipment.php", {
		width: 260,
		matchContains: true,
		mustMatch: true,
		//minChars: 0,
		//multiple: true,
		//highlight: false,
		//multipleSeparator: ",",
		selectFirst: false
	});
	
	$("#equipmentname").result(function(event, data, formatted) {
		$("#ID").val(data[1]);
	});
});
</script>



			  
			 <div class="main" id="main-two-columns" valign="top" class="xtop">

			<div class="left" id="main-left">

				<div class="post">
					<div class="post-body">
                 <div class="section-title"><center>
                 Equipment List
                 </center></div>
		


                
<table>
<tr>
<td><img src="img/search.png" ></td>

<td>  <form autocomplete="off" method="post" action="equipment.php">
		  <input name="sampleNo" id="sampleNo" type="text" class="text" size="25" placeholder="Search Equipment"/>
					    <input type="hidden" name="hide" id="hide" />&nbsp; 
					  <input name="submitsearch" type="submit" class="button" value="Go"/>
				
				</form>	
                </td>
     <td>  <form autocomplete="off" method="post" action="equipment.php">
		 <b>Choose Equipment type:</b>
<select name="equipment" id="equipment"  style="color:#000000; font-weight:100; "> 
<option selected="selected" style="color:#000000; font-weight:600; ">Select Equipment</option>
<?php $a=getEquiped();
foreach ($a as $key => $value) {
	?>
	<option style="color:#B70000;" value="<?php echo $value['ID']."a"; ?>"> <?php echo "<b>".$value['description']."</b>"; ?></option>";
<?php
 getSpecEquiped($value['ID']);
}
 ?></select></p>	
				</form>	
                </td>
                          
                
                
               
                <td>
				 <?php
	$no=mysql_query($k);
    $pages = new Paginator;  
    $pages->items_total = mysql_num_rows($no);  
    $pages->mid_range = 9;  
    $pages->paginate();  
    echo $pages->display_pages();  
    echo "<span style='margin-left:10px'> ". $pages->display_items_per_page() . "</span>";  
				 ?>
				</td>
                
			
				</tr></table>
<table class="data-table">
<tr> <th><center><small> # </small></center></th> 
	<th><center><small>County</small></center></th> 
<th><center><small>MFLCode</small></center></th> 
<th><center><small>Facility </small></center></th> 
<th><center><small>Equipment</small></center></th>
<th><center><small>Equipment Type</small></center></th>
<th><center><small>Status</small></center></th>

</tr>





 <?php  

if(isset($_GET['ipp'])){
	$num=($_GET['ipp']*($_GET['page']-1)+1);
}
else{
$num=1;
}
while($result=mysql_fetch_array($q)){
	?>
	<tr>
<td> <center><small> <?php  echo $num; ?></small></center> </td>
<td> <center><small> <?php  echo $result['county']; ?></small></center> </td>
<td> <center><small> <?php  echo $result['MFLCode']; ?></small></center> </td>
<td> <center><small> <?php if($result['fname']!=""){ echo $result['fname'];} else{ echo $result['facility'];} ?></small></center> </td>
<td> <center><small> <?php if($result['equipmentname']!=""){  echo $result['equipmentname'];} else{ echo $result['description'];}?></small></center> </td>
<td> <center><small> <?php  echo $result['cat']; ?></small></center> </td>
<td> <center><small> <?php  if( $result['status']==1){ echo "Functional";}else echo "Obsolete"; ?></small></center> </td>

</tr>
<?php 
$num++;
}
?>
</table>


</form> 

<!-- hidden inline form -->

</div>
				
				</div>


				
				
				
			</div>

			<?php  		include("includes/sideprogram.php"); ?>

			<div class="clearer">&nbsp;</div>

		</div>

		<div id="dashboard">

			<div class="column left" id="column-1">
				
				<div class="column-content">
				
			

				</div>

			</div>

			<div class="column left" id="column-2">

				<div class="column-content">
				
					

					
				</div>

			</div>

			<div class="column left" id="column-3">

				<div class="column-content">
				
					
				
				</div>

			</div>


			<div class="clearer">&nbsp;</div>

		</div>
        
       
	<?php 
		include("includes/footer.php");
		?>	