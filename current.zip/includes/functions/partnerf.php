<?php
//get specific partner 
		function getSpecificPartner($p){
			$sql="select * from partners where ID='".$p."'";
			$executeSql=mysql_query($sql);
			$result=mysql_fetch_array($executeSql);
			$row=array();
			$row[1] = $result['name'];
			$row[2] = $result['phoneNumber'];
			
			return $row;
			
			
			}


//get all partners 
		function getPartner(){
			$sql="select * from partners";
			$executeSql=mysql_query($sql);
			//$result=mysql_fetch_array($executeSql);
			$myresult=array();
			
			for($i=0;@$result=mysql_fetch_array($executeSql);$i++){
			$myresult[$i]=$result;
				}
			return $myresult;
			
			
			}	

//get next partnerID for login in users table.
		function getNextPartnerId(){
			$sql="select count(ID) from partners";
			$executeSql=mysql_query($sql);
			$result=mysql_fetch_array($executeSql);
			return $result;
			
			}	
			
	
//gets the users in the db
		function getUser(){
			$sql="select * from user";
			$result=mysql_query($sql);
		 	$res_array = array();
        	for($count = 0; @$row = mysql_fetch_array($result); $count++)  {   
            $res_array[$count] = $row;
        		}
       		 return $res_array;                                   
			
			}
	
			
//gets specific user from the db
		function getSpecificUser($user){
			$sql="select * from user WHERE userID='".$user."'";
			$result=mysql_query($sql);
			$row = mysql_fetch_array($result);
			$usern=$row['username'];
       		 echo $usern;   
			
			}	

//add user and set his status to 1( active) and if the user is a partner then partnerID is specified
	function addUser($username,$password,$type,$partnerID,$email){
		if($partnerID!=0){
		$sql="INSERT into user(userName,password,userGroupID,partnerID, status,previousPass,email) values ('".$username."','".$password."','".$type."','".$partnerID."','1','".$password."','".$email."')";
		$executeSql=mysql_query($sql);
		if($executeSql){
			echo "success";
			
			}
			else{
				echo "Registration not done";
				}
		}
		else{
		$sql="INSERT into user(userName,password,userGroupID,partnerID,status) values ('".$username."','".$password."','".$type."','0','1')";
		$executeSql=mysql_query($sql);
		if($executeSql){
			echo "success";
			
			}
			else{
				echo "Registration not done";
				}
		}
	}
	
	

		
//add partner
	function addPatner($name,$phone,$email){
		$sql="INSERT into partners(name,phoneNumber,email) values ('".$name."','".$phone."','".$email."')";
		$executeSql=mysql_query($sql);
		if($executeSql){
			echo "success";
			
			}
			else{
				echo "Registration not done";
				}
		
		}
							
?>